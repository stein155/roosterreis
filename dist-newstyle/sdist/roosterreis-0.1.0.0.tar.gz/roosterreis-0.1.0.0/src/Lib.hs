module Lib
    ( someFunc
    , format
    , get
    , findWordInLine
    ) where

import Network.HTTP
import Data.List.Split (splitOn)
import Data.List (isInfixOf, transpose)
import Data.Maybe (catMaybes)

someFunc :: IO ()
someFunc = get "http://sascalendar.han.nl/getCalendar.aspx?type=ica&id=skmmb" >>= outputResponse

get :: String -> IO String
get url = simpleHTTP (getRequest url) >>= getResponseBody

format :: String -> [String]
format input = lines input 

outputResponse :: String -> IO ()
outputResponse input = print (format input)

findWordInLine :: String -> String -> Bool
findWordInLine = isInfixOf
